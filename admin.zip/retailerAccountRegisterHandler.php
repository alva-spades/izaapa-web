<?php 
  require_once "retailerHandler.php";
  
     print("Hello This is a Login or Sign Up Attempt");
     
    createRetailerAccount()
?>